# Simple program to output all system infomation to a file

# ToDo make this program

# Nothing here for now